import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth.dart';
import 'child.dart';
import 'config.dart';
import 'core.dart';
import 'parent.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseAnonKey);
  runApp(const MyStarsApp());
}

class MyStarsApp extends StatelessWidget {
  const MyStarsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ستاره‌های من',
        debugShowCheckedModeBanner: false,
        locale: const Locale('fa'),
        supportedLocales: const [Locale('fa'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: blue, primary: navy, secondary: gold),
          textTheme: GoogleFonts.vazirmatnTextTheme(),
          scaffoldBackgroundColor: const Color(0xFFF4F7FC),
        ),
        home: const AuthGate(),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: sb.auth.onAuthStateChange,
        builder: (c, _) {
          final s = sb.auth.currentSession;
          if (s == null) return const Welcome();
          return RoleRouter(key: ValueKey(s.user.id));
        },
      );
}

class RoleRouter extends StatefulWidget {
  const RoleRouter({super.key});
  @override
  State<RoleRouter> createState() => _RoleRouterState();
}

class _RoleRouterState extends State<RoleRouter> {
  late Future<Map<String, dynamic>?> f = _load();
  Future<Map<String, dynamic>?> _load() => sb.from('profiles').select().eq('id', uid).maybeSingle();

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) return const Scaffold(body: Center(child: CircularProgressIndicator()));
          final p = s.data;
          if (s.hasError || p == null) {
            return Scaffold(
              body: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('دریافت اطلاعات حساب ممکن نشد'),
                  const SizedBox(height: 8),
                  FilledButton(onPressed: () => setState(() => f = _load()), child: const Text('تلاش دوباره')),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('خروج از حساب')),
                ]),
              ),
            );
          }
          return p['role'] == 'parent' ? const ParentRoot() : const ChildRoot();
        },
      );
}
