import 'package:flutter/material.dart';
import 'core.dart';

class StarCard extends StatelessWidget {
  final String name;
  final int stars;
  const StarCard({super.key, required this.name, required this.stars});
  @override
  Widget build(BuildContext context) {
    final pts = stars ~/ 20, rem = stars % 20;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const CircleAvatar(backgroundColor: navy, child: Icon(Icons.person, color: Colors.white)),
            const SizedBox(width: 12),
            Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            const Icon(Icons.star_rounded, color: gold),
            Text(' ${fa(stars)} ستاره', style: const TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            const Icon(Icons.emoji_events, color: blue, size: 20),
            Text(' ${fa(pts)} امتیاز', style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: rem / 20, color: gold, backgroundColor: const Color(0xFFE8ECF4), minHeight: 8, borderRadius: BorderRadius.circular(8)),
          const SizedBox(height: 4),
          Text('${fa(rem)} از ۲۰ تا امتیاز بعدی', style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    final c = statusColor[status] ?? Colors.grey;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: c.withOpacity(.12), borderRadius: BorderRadius.circular(20)),
      child: Text(statusLabel[status] ?? status, style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }
}

class MissionTile extends StatelessWidget {
  final Json rec;
  final bool parent;
  const MissionTile({super.key, required this.rec, required this.parent});
  @override
  Widget build(BuildContext context) {
    final m = rec['missions'] as Map;
    final who = (rec['profiles'] as Map?)?['display_name'] ?? '';
    return Card(
      child: ListTile(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MissionDetailPage(rec: rec, parent: parent))),
        leading: Icon(m['priority'] == 'important' ? Icons.priority_high : Icons.flag_outlined, color: m['priority'] == 'important' ? red : blue),
        title: Text(m['title'], maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (parent) Text('برای: $who', style: const TextStyle(fontSize: 12)),
          Text('مهلت: ${fmtDate(m['deadline_at'])}', style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          StatusChip(rec['status']),
        ]),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.star_rounded, color: gold),
          Text(fa(m['reward_stars']), style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
        isThreeLine: true,
      ),
    );
  }
}

class MissionDetailPage extends StatelessWidget {
  final Json rec;
  final bool parent;
  const MissionDetailPage({super.key, required this.rec, required this.parent});

  Future<void> _rpc(BuildContext c, String fn, Json p, String ok) async {
    final r = await run(c, () => sb.rpc(fn, params: p), ok: ok);
    if (r != null && c.mounted) Navigator.pop(c);
  }

  @override
  Widget build(BuildContext context) {
    final m = rec['missions'] as Map;
    final st = rec['status'] as String;
    final rid = rec['id'];
    final mActive = m['status'] == 'active';
    final who = (rec['profiles'] as Map?)?['display_name'] ?? '';
    final actions = <Widget>[];
    Widget btn(String t, VoidCallback f, {Color? c, bool outlined = false}) => Padding(
          padding: const EdgeInsets.only(top: 8),
          child: SizedBox(width: double.infinity, child: outlined
              ? OutlinedButton(onPressed: f, child: Text(t))
              : FilledButton(style: FilledButton.styleFrom(backgroundColor: c), onPressed: f, child: Text(t))));

    if (parent) {
      if (st == 'submitted') {
        actions.addAll([
          btn('تأیید انجام کار و ثبت پاداش', () async {
            if (await confirmDlg(context, 'تأیید نهایی', 'پس از تأیید ${fa(m['reward_stars'])} ستاره به $who اضافه می‌شود.') && context.mounted) {
              await _rpc(context, 'review_mission', {'p_recipient': rid, 'p_decision': 'approve', 'p_note': null}, 'پاداش ثبت شد');
            }
          }, c: green),
          btn('درخواست اصلاح و انجام دوباره', () async {
            final n = await askText(context, 'چه چیزی باید اصلاح شود؟', required: true);
            if (n != null && context.mounted) await _rpc(context, 'review_mission', {'p_recipient': rid, 'p_decision': 'revise', 'p_note': n}, 'درخواست اصلاح ارسال شد');
          }, outlined: true),
          btn('رد نتیجه', () async {
            final n = await askText(context, 'دلیل رد را بنویسید', required: true);
            if (n != null && context.mounted) await _rpc(context, 'review_mission', {'p_recipient': rid, 'p_decision': 'reject', 'p_note': n}, 'نتیجه رد شد');
          }, c: red),
        ]);
      }
      if (mActive && ['pending', 'accepted', 'needs_revision', 'expired'].contains(st)) {
        actions.add(btn('تمدید مهلت', () async {
          final d = await pickDateTime(context);
          if (d != null && context.mounted) await _rpc(context, 'extend_deadline', {'p_mission': m['id'], 'p_deadline': d.toUtc().toIso8601String()}, 'مهلت تمدید شد');
        }, outlined: true));
      }
      if (mActive && ['pending', 'accepted', 'needs_revision'].contains(st)) {
        actions.add(btn('لغو مأموریت', () async {
          if (await confirmDlg(context, 'لغو مأموریت', 'مأموریت برای همه گیرندگان لغو می‌شود.') && context.mounted) {
            await _rpc(context, 'cancel_mission', {'p_mission': m['id']}, 'مأموریت لغو شد');
          }
        }, c: red));
      }
    } else {
      if (st == 'pending' && mActive) {
        actions.addAll([
          btn('قبول می‌کنم', () => _rpc(context, 'accept_mission', {'p_recipient': rid}, 'مأموریت را پذیرفتید'), c: green),
          btn('قبول نمی‌کنم', () async {
            if (await confirmDlg(context, 'رد مأموریت', 'مطمئنید؟') && context.mounted) await _rpc(context, 'decline_mission', {'p_recipient': rid}, 'مأموریت رد شد');
          }, outlined: true),
        ]);
      }
      if ((st == 'accepted' || st == 'needs_revision') && mActive) {
        actions.add(btn('کار تمام شد', () async {
          final n = await askText(context, 'توضیحی برای والد بنویسید (اختیاری)');
          if (n != null && context.mounted) await _rpc(context, 'submit_mission', {'p_recipient': rid, 'p_note': n}, 'برای بررسی والد ارسال شد');
        }, c: green));
      }
    }

    Widget row(String k, String v) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 90, child: Text(k, style: const TextStyle(color: Colors.black54))), Expanded(child: Text(v))]));

    return Scaffold(
      appBar: AppBar(title: const Text('جزئیات مأموریت')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(m['title'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Align(alignment: AlignmentDirectional.centerStart, child: StatusChip(st)),
        const SizedBox(height: 12),
        Text(m['description']),
        const Divider(height: 28),
        row('پاداش', '${fa(m['reward_stars'])} ستاره'),
        if (parent) row('گیرنده', '$who'),
        row('حالت', m['assignment_mode'] == 'competitive' ? 'رقابتی (اولین پذیرنده)' : 'هر فرزند جداگانه'),
        row('اولویت', m['priority'] == 'important' ? 'مهم' : 'عادی'),
        if (m['start_at'] != null) row('شروع', fmtDate(m['start_at'])),
        row('مهلت', fmtDate(m['deadline_at'])),
        if (rec['accepted_at'] != null) row('پذیرش', fmtDate(rec['accepted_at'])),
        if (rec['completed_at'] != null) row('اعلام پایان', fmtDate(rec['completed_at'])),
        if (rec['child_note'] != null) row('توضیح فرزند', rec['child_note']),
        if (rec['reviewed_at'] != null) row('زمان بررسی', fmtDate(rec['reviewed_at'])),
        if (rec['review_note'] != null) row('پیام والد', rec['review_note']),
        const SizedBox(height: 12),
        ...actions,
      ]),
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override
  Widget build(BuildContext context) => Live<List<Json>>(
        tables: const ['notifications'],
        loader: () async => rows(await sb.from('notifications').select().eq('user_id', uid).order('created_at', ascending: false).limit(100)),
        builder: (c, d, refresh) => Column(children: [
          Align(alignment: AlignmentDirectional.centerEnd, child: TextButton(
            onPressed: () async { await run(c, () => sb.rpc('mark_all_read')); refresh(); },
            child: const Text('خواندن همه'))),
          Expanded(
            child: d.isEmpty
                ? const Center(child: Text('اعلانی وجود ندارد'))
                : RefreshIndicator(
                    onRefresh: refresh,
                    child: ListView.builder(
                      itemCount: d.length,
                      itemBuilder: (_, i) {
                        final n = d[i];
                        final unread = n['read_at'] == null;
                        return ListTile(
                          leading: Icon(unread ? Icons.notifications_active : Icons.notifications_none, color: unread ? gold : Colors.grey),
                          title: Text(n['title'], style: TextStyle(fontWeight: unread ? FontWeight.bold : FontWeight.normal)),
                          subtitle: Text('${n['message']}\n${fmtDate(n['created_at'])}', style: const TextStyle(fontSize: 12)),
                          isThreeLine: true,
                          onTap: unread ? () async { await run(c, () => sb.rpc('mark_notification_read', params: {'p_id': n['id']})); refresh(); } : null,
                        );
                      },
                    ),
                  ),
          ),
        ]),
      );
}

class HistoryPage extends StatefulWidget {
  final String fid;
  final bool parent;
  const HistoryPage({super.key, required this.fid, required this.parent});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  String tab = 'ledger';
  String? kid, type;
  DateTimeRange? range;
  List<Json> kids = [];

  @override
  void initState() {
    super.initState();
    if (widget.parent) _kids();
  }

  Future<void> _kids() async {
    try {
      final k = rows(await sb.from('family_members').select('user_id, profiles(display_name)').eq('family_id', widget.fid).eq('role', 'child'));
      if (mounted) setState(() => kids = k);
    } catch (_) {}
  }

  Future<List<Json>> load() async {
    final ledger = tab == 'ledger';
    var q = sb.from(ledger ? 'star_ledger' : 'audit_events').select(ledger ? '*, profiles!child_id(display_name)' : '*').eq('family_id', widget.fid);
    if (ledger && kid != null) q = q.eq('child_id', kid!);
    if (type != null) q = q.eq('event_type', type!);
    if (range != null) {
      q = q.gte('created_at', range!.start.toUtc().toIso8601String()).lt('created_at', range!.end.add(const Duration(days: 1)).toUtc().toIso8601String());
    }
    return rows(await q.order('created_at', ascending: false).limit(300));
  }

  @override
  Widget build(BuildContext context) {
    final ledger = tab == 'ledger';
    final types = ledger ? ['mission_reward', 'deduction'] : eventLabel.keys.where((k) => k != 'mission_reward' && k != 'deduction').toList();
    return Column(children: [
      if (widget.parent)
        Padding(
          padding: const EdgeInsets.all(8),
          child: SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'ledger', label: Text('ستاره‌ها')), ButtonSegment(value: 'audit', label: Text('همه رویدادها'))],
            selected: {tab},
            onSelectionChanged: (s) => setState(() { tab = s.first; type = null; kid = null; }),
          ),
        ),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(children: [
          if (widget.parent && ledger)
            DropdownButton<String?>(
              value: kid, hint: const Text('همه فرزندان'),
              items: [const DropdownMenuItem(value: null, child: Text('همه فرزندان')), ...kids.map((k) => DropdownMenuItem(value: k['user_id'] as String, child: Text(k['profiles']['display_name'])))],
              onChanged: (v) => setState(() => kid = v)),
          const SizedBox(width: 12),
          DropdownButton<String?>(
            value: type, hint: const Text('همه انواع'),
            items: [const DropdownMenuItem(value: null, child: Text('همه انواع')), ...types.map((t) => DropdownMenuItem(value: t, child: Text(eventLabel[t] ?? t)))],
            onChanged: (v) => setState(() => type = v)),
          const SizedBox(width: 12),
          TextButton.icon(
            icon: const Icon(Icons.date_range),
            label: Text(range == null ? 'بازه زمانی' : 'حذف بازه'),
            onPressed: () async {
              if (range != null) { setState(() => range = null); return; }
              final r = await showDateRangePicker(context: context, firstDate: DateTime(2024), lastDate: DateTime.now().add(const Duration(days: 1)));
              if (r != null) setState(() => range = r);
            }),
        ]),
      ),
      Expanded(
        child: Live<List<Json>>(
          key: ValueKey('$tab$kid$type$range'),
          tables: [ledger ? 'star_ledger' : 'mission_recipients'],
          loader: load,
          builder: (c, d, refresh) => d.isEmpty
              ? const Center(child: Text('سابقه‌ای یافت نشد'))
              : RefreshIndicator(
                  onRefresh: refresh,
                  child: ListView.builder(
                    itemCount: d.length,
                    itemBuilder: (_, i) => ledger ? _ledgerTile(d[i]) : _auditTile(d[i]),
                  )),
        ),
      ),
    ]);
  }

  Widget _ledgerTile(Json e) {
    final amt = e['amount'] as int;
    final plus = amt > 0;
    return Card(
      child: ListTile(
        leading: CircleAvatar(backgroundColor: (plus ? green : red).withOpacity(.12), child: Icon(plus ? Icons.add : Icons.remove, color: plus ? green : red)),
        title: Text('${eventLabel[e['event_type']]}  ${plus ? '+' : '-'}${fa(amt.abs())} ستاره', style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text([
          if (widget.parent) 'فرزند: ${e['profiles']?['display_name'] ?? ''}',
          if (e['reason'] != null) 'دلیل: ${e['reason']}',
          if (e['note'] != null) 'توضیح: ${e['note']}',
          'موجودی: ${fa(e['balance_before'])} ← ${fa(e['balance_after'])}',
          fmtDate(e['created_at']),
        ].join('\n'), style: const TextStyle(fontSize: 12)),
        isThreeLine: true,
      ),
    );
  }

  Widget _auditTile(Json e) {
    final meta = (e['metadata'] as Map?) ?? {};
    return Card(
      child: ListTile(
        leading: const Icon(Icons.history, color: blue),
        title: Text(eventLabel[e['event_type']] ?? e['event_type']),
        subtitle: Text([if (meta['title'] != null) '${meta['title']}', if (meta['note'] != null) 'پیام: ${meta['note']}', fmtDate(e['created_at'])].join('\n'), style: const TextStyle(fontSize: 12)),
      ),
    );
  }
}
