import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'shared.dart';

class ParentRoot extends StatelessWidget {
  const ParentRoot({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Live<List<Json>>(
          tables: const ['family_members'],
          loader: () async => rows(await sb.from('family_members').select('family_id, families(name)').eq('user_id', uid).eq('role', 'parent').eq('status', 'active')),
          builder: (c, d, refresh) => d.isEmpty
              ? CreateFamilyPage(onDone: refresh)
              : ParentHome(fid: d[0]['family_id'], fname: d[0]['families']['name']),
        ),
      );
}

class CreateFamilyPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const CreateFamilyPage({super.key, required this.onDone});
  @override
  State<CreateFamilyPage> createState() => _CreateFamilyPageState();
}

class _CreateFamilyPageState extends State<CreateFamilyPage> {
  final name = TextEditingController();
  bool busy = false;
  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.family_restroom, size: 80, color: navy),
            const SizedBox(height: 12),
            const Text('خانواده خود را بسازید', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(controller: name, maxLength: 50, decoration: const InputDecoration(labelText: 'نام خانواده', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: busy ? null : () async {
                setState(() => busy = true);
                final r = await run(context, () => sb.rpc('create_family', params: {'p_name': name.text}), ok: 'خانواده ساخته شد');
                if (!mounted) return;
                setState(() => busy = false);
                if (r != null) await widget.onDone();
              },
              child: const Text('ساخت خانواده')),
            TextButton(onPressed: () => sb.auth.signOut(), child: const Text('خروج از حساب')),
          ]),
        ),
      );
}

class ParentHome extends StatefulWidget {
  final String fid, fname;
  const ParentHome({super.key, required this.fid, required this.fname});
  @override
  State<ParentHome> createState() => _ParentHomeState();
}

class _ParentHomeState extends State<ParentHome> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      Dashboard(widget.fid),
      MissionsTab(widget.fid),
      HistoryPage(fid: widget.fid, parent: true),
      const NotificationsPage(),
      SettingsTab(widget.fid),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(widget.fname), backgroundColor: navy, foregroundColor: Colors.white),
      body: pages[i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.flag_outlined), selectedIcon: Icon(Icons.flag), label: 'مأموریت‌ها'),
          NavigationDestination(icon: Icon(Icons.history), label: 'تاریخچه'),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'اعلان‌ها'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final String fid;
  const Dashboard(this.fid, {super.key});

  Future<Json> load() async {
    try { await sb.rpc('expire_missions', params: {'p_family': fid}); } catch (_) {}
    return {
      'kids': rows(await sb.from('family_members').select('user_id, profiles(display_name)').eq('family_id', fid).eq('role', 'child').eq('status', 'active')),
      'bal': rows(await sb.from('star_balances').select().eq('family_id', fid)),
      'reqs': rows(await sb.from('connection_requests').select('id, profiles(display_name)').eq('family_id', fid).eq('status', 'pending')),
      'recs': await loadRecs(fid: fid),
    };
  }

  @override
  Widget build(BuildContext context) => Live<Json>(
        tables: const ['mission_recipients', 'star_balances', 'connection_requests', 'family_members'],
        loader: load,
        builder: (c, d, refresh) {
          final kids = d['kids'] as List<Json>, bal = d['bal'] as List<Json>, reqs = d['reqs'] as List<Json>, recs = d['recs'] as List<Json>;
          int stars(String id) {
            final b = bal.where((x) => x['child_id'] == id);
            return b.isEmpty ? 0 : b.first['total_stars'] as int;
          }
          int cnt(List<String> s) => recs.where((r) => s.contains(r['status'])).length;
          final review = recs.where((r) => r['status'] == 'submitted').toList();
          final name = sb.auth.currentUser?.userMetadata?['display_name'] ?? '';
          Widget stat(String t, int n, Color col) => Chip(avatar: CircleAvatar(backgroundColor: col, child: Text(fa(n), style: const TextStyle(color: Colors.white, fontSize: 11))), label: Text(t, style: const TextStyle(fontSize: 12)));
          return RefreshIndicator(
            onRefresh: refresh,
            child: ListView(padding: const EdgeInsets.all(12), children: [
              Text('سلام $name 👋', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              Text('فرزندان متصل: ${fa(kids.length)} از ۵', style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 8),
              for (final r in reqs)
                Card(
                  color: const Color(0xFFFFF6DA),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${r['profiles']?['display_name'] ?? 'یک فرزند'} درخواست اتصال به خانواده دارد'),
                      Row(children: [
                        TextButton(onPressed: () async { await run(c, () => sb.rpc('review_connection', params: {'p_request': r['id'], 'p_approve': false}), ok: 'درخواست رد شد'); refresh(); }, child: const Text('رد')),
                        FilledButton(onPressed: () async { await run(c, () => sb.rpc('review_connection', params: {'p_request': r['id'], 'p_approve': true}), ok: 'فرزند به خانواده متصل شد'); refresh(); }, child: const Text('تأیید اتصال')),
                      ]),
                    ]),
                  ),
                ),
              Row(children: [
                Expanded(child: FilledButton.icon(
                  onPressed: kids.isEmpty ? () => toast(c, 'ابتدا یک فرزند متصل کنید (تنظیمات ← کد اتصال)', err: true)
                      : () => Navigator.push(c, MaterialPageRoute(builder: (_) => CreateMissionPage(fid: fid))).then((_) => refresh()),
                  icon: const Icon(Icons.add_task), label: const Text('مأموریت جدید'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(
                  onPressed: kids.isEmpty ? () => toast(c, 'فرزندی متصل نیست', err: true)
                      : () => Navigator.push(c, MaterialPageRoute(builder: (_) => DeductPage(fid: fid))).then((_) => refresh()),
                  icon: const Icon(Icons.remove_circle_outline), label: const Text('کسر ستاره'))),
              ]),
              const SizedBox(height: 8),
              if (kids.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('هنوز فرزندی متصل نشده. از «تنظیمات ← کد اتصال فرزند» کد بسازید و به فرزند بدهید.'))),
              for (final k in kids) StarCard(name: k['profiles']['display_name'], stars: stars(k['user_id'])),
              const SizedBox(height: 4),
              Wrap(spacing: 6, children: [
                stat('در انتظار پذیرش', cnt(['pending']), blue),
                stat('در حال انجام', cnt(['accepted', 'needs_revision']), const Color(0xFF7B5BD6)),
                stat('در انتظار بررسی', cnt(['submitted']), const Color(0xFFE08A00)),
                stat('تأییدشده', cnt(['approved']), green),
                stat('ردشده/منقضی', cnt(['rejected', 'declined', 'expired', 'cancelled']), red),
              ]),
              if (review.isNotEmpty) ...[
                const Padding(padding: EdgeInsets.only(top: 12, bottom: 4), child: Text('منتظر بررسی شما', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                for (final r in review) MissionTile(rec: r, parent: true),
              ],
            ]),
          );
        },
      );
}

class MissionsTab extends StatefulWidget {
  final String fid;
  const MissionsTab(this.fid, {super.key});
  @override
  State<MissionsTab> createState() => _MissionsTabState();
}

class _MissionsTabState extends State<MissionsTab> {
  String f = 'all';
  static const groups = <String, List<String>?>{
    'all': null,
    'wait': ['pending'],
    'doing': ['accepted', 'needs_revision'],
    'review': ['submitted'],
    'done': ['approved'],
    'other': ['rejected', 'declined', 'taken_by_other', 'cancelled', 'expired'],
  };
  static const names = {'all': 'همه', 'wait': 'در انتظار پذیرش', 'doing': 'در حال انجام', 'review': 'نیاز به بررسی', 'done': 'تأییدشده', 'other': 'سایر'};

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CreateMissionPage(fid: widget.fid))),
          icon: const Icon(Icons.add), label: const Text('مأموریت جدید')),
        body: Column(children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              for (final e in names.entries)
                Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: Text(e.value), selected: f == e.key, onSelected: (_) => setState(() => f = e.key))),
            ]),
          ),
          Expanded(
            child: Live<List<Json>>(
              tables: const ['mission_recipients'],
              loader: () => loadRecs(fid: widget.fid),
              builder: (c, d, refresh) {
                final l = groups[f] == null ? d : d.where((r) => groups[f]!.contains(r['status'])).toList();
                if (l.isEmpty) return const Center(child: Text('مأموریتی وجود ندارد'));
                return RefreshIndicator(onRefresh: refresh, child: ListView(padding: const EdgeInsets.only(bottom: 80), children: [for (final r in l) MissionTile(rec: r, parent: true)]));
              },
            ),
          ),
        ]),
      );
}

class CreateMissionPage extends StatefulWidget {
  final String fid;
  const CreateMissionPage({super.key, required this.fid});
  @override
  State<CreateMissionPage> createState() => _CreateMissionPageState();
}

class _CreateMissionPageState extends State<CreateMissionPage> {
  final title = TextEditingController(), desc = TextEditingController(), reward = TextEditingController(text: '1');
  DateTime? start, deadline;
  String mode = 'individual';
  bool important = false, busy = false;
  List<Json> kids = [];
  final sel = <String>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final k = rows(await sb.from('family_members').select('user_id, profiles(display_name)').eq('family_id', widget.fid).eq('role', 'child').eq('status', 'active'));
      if (mounted) setState(() => kids = k);
    } catch (_) {
      if (mounted) toast(context, 'دریافت فهرست فرزندان ممکن نشد', err: true);
    }
  }

  Future<void> submit() async {
    final t = title.text.trim(), d = desc.text.trim();
    final r = int.tryParse(en(reward.text.trim()));
    String? e;
    if (t.isEmpty) e = 'عنوان را وارد کنید';
    else if (d.isEmpty) e = 'توضیحات را وارد کنید';
    else if (r == null || r <= 0) e = 'تعداد ستاره باید عدد صحیح مثبت باشد';
    else if (deadline == null) e = 'مهلت پایان را مشخص کنید';
    else if (!deadline!.isAfter(DateTime.now())) e = 'مهلت باید در آینده باشد';
    else if (start != null && !deadline!.isAfter(start!)) e = 'مهلت پایان باید بعد از شروع باشد';
    else if (sel.isEmpty) e = 'حداقل یک فرزند را انتخاب کنید';
    if (e != null) { toast(context, e, err: true); return; }
    setState(() => busy = true);
    final ok = await run(context, () => sb.rpc('create_mission', params: {
      'p_family': widget.fid, 'p_title': t, 'p_desc': d, 'p_reward': r,
      'p_start': start?.toUtc().toIso8601String(), 'p_deadline': deadline!.toUtc().toIso8601String(),
      'p_children': sel.toList(), 'p_mode': sel.length > 1 ? mode : 'individual', 'p_priority': important ? 'important' : 'normal',
    }), ok: 'مأموریت ارسال شد');
    if (!mounted) return;
    setState(() => busy = false);
    if (ok != null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('مأموریت جدید')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: title, maxLength: 80, decoration: const InputDecoration(labelText: 'عنوان *', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: desc, maxLength: 500, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText: 'توضیحات *', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: reward, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'پاداش (تعداد ستاره) *', prefixIcon: Icon(Icons.star_rounded, color: gold), border: OutlineInputBorder())),
          const SizedBox(height: 12),
          ListTile(
            shape: RoundedRectangleBorder(side: const BorderSide(color: Colors.black26), borderRadius: BorderRadius.circular(8)),
            leading: const Icon(Icons.play_circle_outline), title: Text(start == null ? 'تاریخ شروع (اختیاری)' : fmtDate(start!.toUtc().toIso8601String())),
            trailing: start == null ? null : IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => start = null)),
            onTap: () async { final d = await pickDateTime(context); if (d != null) setState(() => start = d); }),
          const SizedBox(height: 8),
          ListTile(
            shape: RoundedRectangleBorder(side: const BorderSide(color: Colors.black26), borderRadius: BorderRadius.circular(8)),
            leading: const Icon(Icons.timer_outlined), title: Text(deadline == null ? 'مهلت پایان * (تاریخ و ساعت)' : fmtDate(deadline!.toUtc().toIso8601String())),
            onTap: () async { final d = await pickDateTime(context, initial: deadline); if (d != null) setState(() => deadline = d); }),
          SwitchListTile(title: const Text('مأموریت مهم'), value: important, onChanged: (v) => setState(() => important = v)),
          const Divider(),
          const Text('گیرندگان *', style: TextStyle(fontWeight: FontWeight.bold)),
          if (kids.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('فرزند متصلی وجود ندارد')),
          for (final k in kids)
            CheckboxListTile(
              value: sel.contains(k['user_id']), title: Text(k['profiles']['display_name']),
              onChanged: (v) => setState(() => v == true ? sel.add(k['user_id']) : sel.remove(k['user_id']))),
          if (sel.length > 1) ...[
            const SizedBox(height: 8),
            const Text('حالت مأموریت برای چند فرزند', style: TextStyle(fontWeight: FontWeight.bold)),
            RadioListTile<String>(value: 'competitive', groupValue: mode, onChanged: (v) => setState(() => mode = v!), title: const Text('رقابتی'), subtitle: const Text('اولین فرزندی که بپذیرد مسئول است؛ بقیه پیام «توسط فرزند دیگری پذیرفته شد» می‌بینند.')),
            RadioListTile<String>(value: 'individual', groupValue: mode, onChanged: (v) => setState(() => mode = v!), title: const Text('هر فرزند جداگانه'), subtitle: const Text('هر فرزند پذیرش، انجام و پاداش مستقل دارد.')),
          ],
          const SizedBox(height: 12),
          FilledButton(onPressed: busy ? null : submit, style: FilledButton.styleFrom(padding: const EdgeInsets.all(14)), child: const Text('ارسال مأموریت')),
        ]),
      );
}

class DeductPage extends StatefulWidget {
  final String fid;
  const DeductPage({super.key, required this.fid});
  @override
  State<DeductPage> createState() => _DeductPageState();
}

class _DeductPageState extends State<DeductPage> {
  static const reasons = ['انجام‌ندادن مسئولیت', 'رعایت‌نکردن توافق خانوادگی', 'رفتار نامناسب', 'انجام‌ندادن مأموریت طبق توافق', 'سایر'];
  List<Json> kids = [], bal = [];
  String? kid, reason;
  final amount = TextEditingController(), note = TextEditingController();
  final key = '${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(1 << 30)}'; // کلید یکتا برای جلوگیری از کسر تکراری
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final k = rows(await sb.from('family_members').select('user_id, profiles(display_name)').eq('family_id', widget.fid).eq('role', 'child').eq('status', 'active'));
      final b = rows(await sb.from('star_balances').select().eq('family_id', widget.fid));
      if (mounted) setState(() { kids = k; bal = b; });
    } catch (_) {
      if (mounted) toast(context, 'اتصال برقرار نشد', err: true);
    }
  }

  int cur(String id) {
    final b = bal.where((x) => x['child_id'] == id);
    return b.isEmpty ? 0 : b.first['total_stars'] as int;
  }

  Future<void> review() async {
    final a = int.tryParse(en(amount.text.trim()));
    String? e;
    if (kid == null) e = 'فرزند را انتخاب کنید';
    else if (a == null || a <= 0) e = 'تعداد ستاره باید عدد صحیح مثبت باشد';
    else if (reason == null) e = 'دلیل کسر را انتخاب کنید';
    else if (a > cur(kid!)) e = 'ستاره کافی نیست؛ موجودی فعلی ${fa(cur(kid!))} است';
    if (e != null) { toast(context, e, err: true); return; }
    final name = kids.firstWhere((k) => k['user_id'] == kid)['profiles']['display_name'];
    final ok = await confirmDlg(context, 'بررسی نهایی کسر ستاره',
        'فرزند: $name\nموجودی فعلی: ${fa(cur(kid!))}\nکسر: ${fa(a!)}\nموجودی پس از کسر: ${fa(cur(kid!) - a)}\nدلیل: $reason${note.text.trim().isEmpty ? '' : '\nتوضیح: ${note.text.trim()}'}');
    if (!ok || !mounted) return;
    setState(() => busy = true);
    final r = await run(context, () => sb.rpc('deduct_stars', params: {'p_family': widget.fid, 'p_child': kid, 'p_amount': a, 'p_reason': reason, 'p_note': note.text.trim(), 'p_key': key}), ok: 'ستاره‌ها کسر شد');
    if (!mounted) return;
    setState(() => busy = false);
    if (r != null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('کسر ستاره')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          DropdownButtonFormField<String>(
            value: kid, decoration: const InputDecoration(labelText: 'فرزند', border: OutlineInputBorder()),
            items: [for (final k in kids) DropdownMenuItem(value: k['user_id'] as String, child: Text('${k['profiles']['display_name']}  (${fa(cur(k['user_id']))} ستاره)'))],
            onChanged: (v) => setState(() => kid = v)),
          const SizedBox(height: 12),
          TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'تعداد ستاره برای کسر', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: reason, decoration: const InputDecoration(labelText: 'دلیل کسر', border: OutlineInputBorder()),
            items: [for (final r in reasons) DropdownMenuItem(value: r, child: Text(r))], onChanged: (v) => setState(() => reason = v)),
          const SizedBox(height: 12),
          TextField(controller: note, maxLength: 300, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیح تکمیلی', border: OutlineInputBorder())),
          FilledButton(onPressed: busy ? null : review, style: FilledButton.styleFrom(backgroundColor: red, padding: const EdgeInsets.all(14)), child: const Text('بررسی نهایی و کسر')),
        ]),
      );
}

class SettingsTab extends StatelessWidget {
  final String fid;
  const SettingsTab(this.fid, {super.key});

  Future<void> _code(BuildContext c) async {
    final code = await run(c, () => sb.rpc('generate_connection_code', params: {'p_family': fid}));
    if (code == null || !c.mounted) return;
    showDialog(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('کد اتصال فرزند'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          SelectableText(code.toString(), textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 34, letterSpacing: 4, fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 8),
          const Text('این کد ۲۴ ساعت معتبر است و فقط یک‌بار نمایش داده می‌شود. تولید کد جدید، کد قبلی را باطل می‌کند. هر فرزند پس از وارد کردن کد باید توسط شما تأیید شود.', style: TextStyle(fontSize: 12)),
        ]),
        actions: [
          TextButton(onPressed: () { Clipboard.setData(ClipboardData(text: code.toString())); Navigator.pop(ctx); toast(c, 'کد کپی شد'); }, child: const Text('کپی')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('بستن')),
        ],
      ),
    );
  }

  Future<void> _backup(BuildContext c) async {
    final data = await run(c, () async => {
          'exported_at': DateTime.now().toUtc().toIso8601String(),
          'members': await sb.from('family_members').select('*, profiles(display_name)').eq('family_id', fid),
          'missions': await sb.from('missions').select().eq('family_id', fid),
          'recipients': await sb.from('mission_recipients').select().eq('family_id', fid),
          'balances': await sb.from('star_balances').select().eq('family_id', fid),
          'ledger': await sb.from('star_ledger').select().eq('family_id', fid).order('created_at'),
          'audit': await sb.from('audit_events').select().eq('family_id', fid).order('created_at'),
        });
    if (data == null || !c.mounted) return;
    await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(data)));
    if (c.mounted) toast(c, 'پشتیبان (JSON) در کلیپ‌بورد کپی شد؛ در یک یادداشت یا فایل امن ذخیره کنید');
  }

  @override
  Widget build(BuildContext context) => ListView(children: [
        ListTile(leading: const Icon(Icons.key), title: const Text('کد اتصال فرزند'), subtitle: const Text('ساخت کد جدید'), onTap: () => _code(context)),
        ListTile(leading: const Icon(Icons.groups), title: const Text('اعضای خانواده'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MembersPage(fid)))),
        ListTile(leading: const Icon(Icons.backup), title: const Text('پشتیبان‌گیری'), subtitle: const Text('کپی اطلاعات خانواده به‌صورت JSON'), onTap: () => _backup(context)),
        const Divider(),
        ListTile(leading: const Icon(Icons.logout, color: red), title: const Text('خروج از حساب'), subtitle: const Text('اطلاعات روی سرور می‌ماند'), onTap: () async {
          if (await confirmDlg(context, 'خروج', 'از حساب خارج می‌شوید؟')) await sb.auth.signOut();
        }),
      ]);
}

class MembersPage extends StatelessWidget {
  final String fid;
  const MembersPage(this.fid, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('اعضای خانواده')),
        body: Live<List<Json>>(
          tables: const ['family_members'],
          loader: () async => rows(await sb.from('family_members').select('user_id, role, status, joined_at, profiles(display_name)').eq('family_id', fid).order('joined_at')),
          builder: (c, d, refresh) => ListView(children: [
            for (final m in d)
              ListTile(
                leading: Icon(m['role'] == 'parent' ? Icons.shield : Icons.child_care, color: m['status'] == 'active' ? navy : Colors.grey),
                title: Text(m['profiles']['display_name']),
                subtitle: Text('${m['role'] == 'parent' ? 'والد' : 'فرزند'} — ${m['status'] == 'active' ? 'فعال' : 'جداشده'}'),
                trailing: (m['role'] == 'child' && m['status'] == 'active')
                    ? IconButton(
                        icon: const Icon(Icons.person_remove, color: red),
                        onPressed: () async {
                          if (await confirmDlg(c, 'جداکردن فرزند', 'سابقه و ستاره‌های ${m['profiles']['display_name']} حفظ می‌شود، اما دسترسی او قطع می‌شود.') && c.mounted) {
                            await run(c, () => sb.rpc('remove_member', params: {'p_family': fid, 'p_child': m['user_id']}), ok: 'فرزند جدا شد');
                            refresh();
                          }
                        })
                    : null,
              ),
          ]),
        ),
      );
}
