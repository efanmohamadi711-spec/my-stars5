// مقادیر را از Supabase > Project Settings > API کپی کنید.
// فقط کلید anon/public اینجا قرار می‌گیرد؛ هرگز service_role را در برنامه نگذارید.
const kSupabaseUrl = 'https://YOUR-PROJECT.supabase.co';
const kSupabaseAnonKey = 'YOUR-ANON-PUBLIC-KEY';
