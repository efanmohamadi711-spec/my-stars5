import 'package:flutter/material.dart';
import 'core.dart';

class Welcome extends StatelessWidget {
  const Welcome({super.key});
  void _go(BuildContext c, String role, bool login) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => AuthPage(role: role, login: login)));

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [navy, Color(0xFF1F4FA3)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(28),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.star_rounded, size: 110, color: gold),
                  const SizedBox(height: 8),
                  const Text('ستاره‌های من', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 4),
                  const Text('مأموریت، مسئولیت و پاداش خانوادگی', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 40),
                  SizedBox(width: double.infinity, child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy, padding: const EdgeInsets.all(16)),
                    onPressed: () => _go(context, 'parent', false), icon: const Icon(Icons.family_restroom), label: const Text('ورود به‌عنوان والد'))),
                  const SizedBox(height: 12),
                  SizedBox(width: double.infinity, child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: navy, padding: const EdgeInsets.all(16)),
                    onPressed: () => _go(context, 'child', false), icon: const Icon(Icons.child_care), label: const Text('ورود به‌عنوان فرزند'))),
                  const SizedBox(height: 12),
                  SizedBox(width: double.infinity, child: OutlinedButton(
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54), padding: const EdgeInsets.all(16)),
                    onPressed: () => _go(context, 'parent', true), child: const Text('ورود به حساب موجود'))),
                  TextButton(onPressed: () => _forgot(context), child: const Text('بازیابی حساب / فراموشی رمز', style: TextStyle(color: Colors.white70))),
                ]),
              ),
            ),
          ),
        ),
      );
}

Future<void> _forgot(BuildContext c) async {
  final email = await askText(c, 'ایمیل حساب خود را بنویسید', required: true, hint: 'example@mail.com');
  if (email == null || email.isEmpty || !c.mounted) return;
  await run(c, () => sb.auth.resetPasswordForEmail(email), ok: 'اگر این ایمیل ثبت شده باشد، لینک بازیابی ارسال شد');
}

class AuthPage extends StatefulWidget {
  final String role;
  final bool login;
  const AuthPage({super.key, required this.role, required this.login});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  late bool login = widget.login;
  final name = TextEditingController(), email = TextEditingController(), pass = TextEditingController();
  bool busy = false, hide = true;

  Future<void> submit() async {
    final n = name.text.trim(), e = email.text.trim(), p = pass.text;
    String? err;
    if (!login && n.length < 2) err = 'نام نمایشی را وارد کنید';
    else if (!e.contains('@') || !e.contains('.')) err = 'ایمیل معتبر وارد کنید';
    else if (p.length < 8) err = 'رمز عبور باید حداقل ۸ نویسه باشد';
    if (err != null) { toast(context, err, err: true); return; }
    setState(() => busy = true);
    final r = await run(context, () async {
      if (login) {
        return (await sb.auth.signInWithPassword(email: e, password: p)).session;
      }
      final res = await sb.auth.signUp(email: e, password: p, data: {'display_name': n, 'role': widget.role});
      return res.session;
    });
    if (!mounted) return;
    setState(() => busy = false);
    if (r == null) return;
    if (sb.auth.currentSession == null) {
      toast(context, 'حساب ساخته شد؛ ایمیل تأیید را باز کنید (یا تأیید ایمیل را در Supabase خاموش کنید).', err: true);
      return;
    }
    Navigator.of(context).popUntil((x) => x.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final parent = widget.role == 'parent';
    return Scaffold(
      appBar: AppBar(title: Text(login ? 'ورود به حساب' : (parent ? 'ثبت‌نام والد' : 'ثبت‌نام فرزند'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        if (!login) TextField(controller: name, maxLength: 40, decoration: const InputDecoration(labelText: 'نام نمایشی', border: OutlineInputBorder())),
        if (!login) const SizedBox(height: 8),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'ایمیل', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: pass, obscureText: hide, textDirection: TextDirection.ltr, decoration: InputDecoration(
          labelText: 'رمز عبور (حداقل ۸ نویسه)', border: const OutlineInputBorder(),
          suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => hide = !hide)))),
        const SizedBox(height: 20),
        FilledButton(onPressed: busy ? null : submit, style: FilledButton.styleFrom(padding: const EdgeInsets.all(14)),
          child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(login ? 'ورود' : 'ساخت حساب')),
        TextButton(onPressed: () => setState(() => login = !login), child: Text(login ? 'حساب ندارید؟ ثبت‌نام (${parent ? 'والد' : 'فرزند'})' : 'حساب دارم؛ ورود')),
        if (login) TextButton(onPressed: () => _forgot(context), child: const Text('فراموشی رمز عبور')),
      ]),
    );
  }
}
