import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final sb = Supabase.instance.client;
String get uid => sb.auth.currentUser!.id;

const navy = Color(0xFF14284B);
const blue = Color(0xFF2F6FDB);
const gold = Color(0xFFF5B301);
const green = Color(0xFF2E9E5B);
const red = Color(0xFFD64545);

typedef Json = Map<String, dynamic>;
List<Json> rows(dynamic d) => List<Json>.from((d as List).map((e) => Json.from(e as Map)));

String fa(Object n) {
  const e = '0123456789', f = '۰۱۲۳۴۵۶۷۸۹';
  var s = n.toString();
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(e[i], f[i]);
  }
  return s;
}

String en(String s) {
  const f = '۰۱۲۳۴۵۶۷۸۹', a = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(f[i], '$i').replaceAll(a[i], '$i');
  }
  return s;
}

String fmtDate(String? iso) {
  if (iso == null) return '-';
  final d = DateTime.parse(iso).toLocal();
  String p(int x) => x.toString().padLeft(2, '0');
  return fa('${d.year}/${p(d.month)}/${p(d.day)}  ${p(d.hour)}:${p(d.minute)}');
}

void toast(BuildContext c, String m, {bool err = false}) {
  final s = ScaffoldMessenger.of(c);
  s.hideCurrentSnackBar();
  s.showSnackBar(SnackBar(content: Text(m), backgroundColor: err ? red : green, behavior: SnackBarBehavior.floating));
}

String _pgMsg(PostgrestException e) =>
    RegExp(r'[\u0600-\u06FF]').hasMatch(e.message) ? e.message : 'خطای غیرمنتظره از سرور (${e.code ?? '-'})';

/// اجرای عملیات سرور؛ در صورت موفقیت مقدار غیر null و در صورت خطا null برمی‌گرداند.
Future<dynamic> run(BuildContext c, Future<dynamic> Function() f, {String? ok}) async {
  try {
    final r = await f();
    if (ok != null && c.mounted) toast(c, ok);
    return r ?? true;
  } on PostgrestException catch (e) {
    if (c.mounted) toast(c, _pgMsg(e), err: true);
  } on AuthException catch (e) {
    final m = e.message.toLowerCase();
    final t = m.contains('invalid login') ? 'ایمیل یا رمز عبور اشتباه است'
        : m.contains('already registered') ? 'این ایمیل قبلاً ثبت شده است'
        : m.contains('password') ? 'رمز عبور باید حداقل ۸ نویسه باشد'
        : m.contains('rate') ? 'تعداد تلاش زیاد بود؛ کمی بعد دوباره امتحان کنید'
        : 'خطا در احراز هویت';
    if (c.mounted) toast(c, t, err: true);
  } catch (_) {
    if (c.mounted) toast(c, 'اتصال به سرور برقرار نشد؛ عملیات انجام نشد.', err: true);
  }
  return null;
}

Future<bool> confirmDlg(BuildContext c, String title, String body) async =>
    (await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(title: Text(title), content: Text(body), actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأیید')),
      ]),
    )) ?? false;

Future<String?> askText(BuildContext c, String title, {bool required = false, String hint = ''}) {
  final ctl = TextEditingController();
  String? err;
  return showDialog<String>(
    context: c,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctl, maxLines: 3, maxLength: 300, decoration: InputDecoration(hintText: hint, errorText: err)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
          FilledButton(
            onPressed: () {
              if (required && ctl.text.trim().isEmpty) {
                set(() => err = 'این بخش الزامی است');
                return;
              }
              Navigator.pop(ctx, ctl.text.trim());
            },
            child: const Text('ثبت'),
          ),
        ],
      ),
    ),
  );
}

Future<DateTime?> pickDateTime(BuildContext c, {DateTime? initial}) async {
  final now = DateTime.now();
  final d = await showDatePicker(
    context: c,
    initialDate: initial ?? now.add(const Duration(days: 1)),
    firstDate: now.subtract(const Duration(days: 1)),
    lastDate: now.add(const Duration(days: 730)),
  );
  if (d == null || !c.mounted) return null;
  final t = await showTimePicker(context: c, initialTime: TimeOfDay.fromDateTime(initial ?? now));
  if (t == null) return null;
  return DateTime(d.year, d.month, d.day, t.hour, t.minute);
}

const recSelect =
    'id,status,child_id,child_note,review_note,accepted_at,completed_at,reviewed_at,mission_id,created_at,'
    'missions(id,title,description,reward_stars,deadline_at,start_at,assignment_mode,status,priority,family_id),'
    'profiles(display_name)';

Future<List<Json>> loadRecs({String? fid, String? child}) async {
  var q = sb.from('mission_recipients').select(recSelect);
  if (fid != null) q = q.eq('family_id', fid);
  if (child != null) q = q.eq('child_id', child);
  return rows(await q.order('created_at', ascending: false));
}

const statusLabel = {
  'pending': 'در انتظار پذیرش',
  'accepted': 'در حال انجام',
  'submitted': 'در انتظار بررسی والد',
  'needs_revision': 'نیازمند اصلاح',
  'approved': 'تأییدشده',
  'rejected': 'ردشده',
  'declined': 'رد شده توسط فرزند',
  'taken_by_other': 'پذیرفته‌شده توسط دیگری',
  'cancelled': 'لغوشده',
  'expired': 'منقضی‌شده',
};
const statusColor = {
  'pending': blue,
  'accepted': Color(0xFF7B5BD6),
  'submitted': Color(0xFFE08A00),
  'needs_revision': Color(0xFFE08A00),
  'approved': green,
  'rejected': red,
  'declined': red,
  'taken_by_other': Colors.grey,
  'cancelled': Colors.grey,
  'expired': red,
};
const eventLabel = {
  'mission_reward': 'دریافت پاداش',
  'deduction': 'کسر ستاره',
  'family_created': 'ایجاد خانواده',
  'code_generated': 'تولید کد اتصال',
  'connection_requested': 'درخواست اتصال',
  'connection_approved': 'تأیید اتصال',
  'connection_rejected': 'رد اتصال',
  'member_removed': 'جداشدن عضو',
  'mission_created': 'ساخت مأموریت',
  'mission_accepted': 'پذیرش مأموریت',
  'mission_declined': 'رد مأموریت توسط فرزند',
  'mission_submitted': 'اعلام پایان کار',
  'mission_approved': 'تأیید نتیجه',
  'mission_rejected': 'رد نتیجه',
  'mission_revision': 'درخواست اصلاح',
  'mission_cancelled': 'لغو مأموریت',
  'deadline_extended': 'تمدید مهلت',
};

/// بارگذاری داده + به‌روزرسانی خودکار با تغییر جدول‌ها (Realtime) + حفظ آخرین داده هنگام قطع اینترنت
class Live<T> extends StatefulWidget {
  final Future<T> Function() loader;
  final List<String> tables;
  final Widget Function(BuildContext, T, Future<void> Function()) builder;
  const Live({super.key, required this.loader, required this.tables, required this.builder});
  @override
  State<Live<T>> createState() => _LiveState<T>();
}

class _LiveState<T> extends State<Live<T>> {
  T? data;
  Object? err;
  bool loading = true;
  RealtimeChannel? ch;
  Timer? t;

  @override
  void initState() {
    super.initState();
    load();
    final c = sb.channel('live-${identityHashCode(this)}');
    for (final tb in widget.tables) {
      c.onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: tb,
        callback: (_) {
          t?.cancel();
          t = Timer(const Duration(milliseconds: 400), load);
        },
      );
    }
    c.subscribe();
    ch = c;
  }

  Future<void> load() async {
    try {
      final d = await widget.loader();
      if (mounted) setState(() { data = d; err = null; loading = false; });
    } catch (e) {
      if (mounted) setState(() { err = e; loading = false; });
    }
  }

  @override
  void dispose() {
    t?.cancel();
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (data == null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off, size: 48, color: Colors.grey),
          const SizedBox(height: 8),
          const Text('اتصال به سرور برقرار نشد'),
          const SizedBox(height: 8),
          FilledButton(onPressed: () { setState(() => loading = true); load(); }, child: const Text('تلاش دوباره')),
        ]),
      );
    }
    return Column(children: [
      if (err != null)
        Container(
          width: double.infinity,
          color: const Color(0xFFFFE9B5),
          padding: const EdgeInsets.all(6),
          child: const Text('آفلاین یا خطای اتصال — آخرین اطلاعات دریافت‌شده نمایش داده می‌شود', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
        ),
      Expanded(child: widget.builder(context, data as T, load)),
    ]);
  }
}
