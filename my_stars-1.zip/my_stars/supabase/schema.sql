-- ستاره‌های من — اسکریپت کامل پایگاه داده (Supabase / PostgreSQL)
-- این فایل را یک‌بار در SQL Editor اجرا کنید.
create extension if not exists pgcrypto with schema extensions;

-- ========== جدول‌ها ==========
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  role text not null check (role in ('parent','child')),
  account_status text not null default 'active',
  created_at timestamptz not null default now()
);
create table public.families (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 50),
  owner_id uuid not null references public.profiles(id),
  status text not null default 'active',
  created_at timestamptz not null default now()
);
create table public.family_members (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  user_id uuid not null references public.profiles(id),
  role text not null check (role in ('parent','child')),
  status text not null default 'active' check (status in ('active','removed')),
  joined_at timestamptz not null default now(),
  unique (family_id, user_id)
);
create unique index one_active_family_per_child on public.family_members(user_id) where role='child' and status='active';

create table public.connection_codes (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  code_hash text not null unique,
  expires_at timestamptz not null,
  max_uses int not null default 5,
  uses_count int not null default 0,
  status text not null default 'active' check (status in ('active','revoked')),
  created_at timestamptz not null default now()
);
create table public.code_attempts (user_id uuid not null, at timestamptz not null default now());
create table public.connection_requests (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  child_id uuid not null references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id)
);
create unique index one_pending_request on public.connection_requests(family_id, child_id) where status='pending';

create table public.missions (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  created_by uuid not null references public.profiles(id),
  title text not null check (char_length(trim(title)) between 1 and 80),
  description text not null check (char_length(trim(description)) between 1 and 500),
  reward_stars int not null check (reward_stars > 0 and reward_stars <= 1000),
  start_at timestamptz,
  deadline_at timestamptz not null,
  assignment_mode text not null check (assignment_mode in ('competitive','individual')),
  priority text not null default 'normal' check (priority in ('normal','important')),
  status text not null default 'active' check (status in ('active','cancelled')),
  created_at timestamptz not null default now(),
  check (start_at is null or deadline_at > start_at)
);
create table public.mission_recipients (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid not null references public.missions(id) on delete cascade,
  family_id uuid not null references public.families(id) on delete cascade,
  child_id uuid not null references public.profiles(id),
  status text not null default 'pending' check (status in
    ('pending','accepted','submitted','needs_revision','approved','rejected','declined','taken_by_other','cancelled','expired')),
  accepted_at timestamptz, completed_at timestamptz, reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id),
  child_note text, review_note text,
  created_at timestamptz not null default now(),
  unique (mission_id, child_id)
);
create table public.star_balances (
  family_id uuid not null references public.families(id) on delete cascade,
  child_id uuid not null references public.profiles(id),
  total_stars int not null default 0 check (total_stars >= 0),
  primary key (family_id, child_id)
);
create table public.star_ledger (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id),
  child_id uuid not null references public.profiles(id),
  actor_id uuid not null references public.profiles(id),
  event_type text not null check (event_type in ('mission_reward','deduction')),
  amount int not null check (amount <> 0),
  balance_before int not null check (balance_before >= 0),
  balance_after int not null check (balance_after >= 0),
  reason text, note text,
  mission_id uuid references public.missions(id),
  idempotency_key text not null unique,
  created_at timestamptz not null default now()
);
-- فقط یک پاداش نهایی برای هر مأموریت و هر فرزند
create unique index one_reward_per_mission_child on public.star_ledger(mission_id, child_id) where event_type='mission_reward';

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null, title text not null, message text not null,
  related_entity_id uuid, read_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.notifications(user_id, created_at desc);
create table public.audit_events (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id),
  actor_id uuid, event_type text not null, entity_type text, entity_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index on public.audit_events(family_id, created_at desc);
create index on public.star_ledger(family_id, created_at desc);

-- سوابق غیرقابل تغییر
create function public.block_change() returns trigger language plpgsql as $$
begin raise exception 'سوابق قابل ویرایش یا حذف نیستند'; end $$;
create trigger ledger_immutable before update or delete on public.star_ledger for each row execute function public.block_change();
create trigger audit_immutable before update or delete on public.audit_events for each row execute function public.block_change();

-- ========== ساخت پروفایل هنگام ثبت‌نام ==========
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare r text := coalesce(new.raw_user_meta_data->>'role','');
begin
  if r not in ('parent','child') then r := 'child'; end if;
  insert into public.profiles(id, display_name, role)
  values (new.id, left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'),''),'کاربر'),40), r);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ========== توابع کمکی ==========
create function public.is_member(fid uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from family_members where family_id=fid and user_id=auth.uid() and status='active') $$;
create function public.is_parent(fid uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from family_members where family_id=fid and user_id=auth.uid() and role='parent' and status='active') $$;
create function public.push_notification(p_user uuid, p_type text, p_title text, p_msg text, p_entity uuid default null)
returns void language sql security definer set search_path = public as $$
  insert into notifications(user_id,type,title,message,related_entity_id) values (p_user,p_type,p_title,p_msg,p_entity) $$;
create function public.push_to_parents(p_fid uuid, p_type text, p_title text, p_msg text, p_entity uuid default null)
returns void language sql security definer set search_path = public as $$
  insert into notifications(user_id,type,title,message,related_entity_id)
  select user_id,p_type,p_title,p_msg,p_entity from family_members where family_id=p_fid and role='parent' and status='active' $$;
create function public.log_event(p_fid uuid, p_actor uuid, p_event text, p_etype text, p_eid uuid, p_meta jsonb default '{}')
returns void language sql security definer set search_path = public as $$
  insert into audit_events(family_id,actor_id,event_type,entity_type,entity_id,metadata) values (p_fid,p_actor,p_event,p_etype,p_eid,p_meta) $$;

-- ========== خانواده و اتصال ==========
create function public.create_family(p_name text) returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare me uuid := auth.uid(); fid uuid;
begin
  if me is null then raise exception 'ابتدا وارد حساب شوید'; end if;
  if (select role from profiles where id=me) <> 'parent' then raise exception 'فقط والد می‌تواند خانواده بسازد'; end if;
  if char_length(trim(p_name)) < 2 then raise exception 'نام خانواده باید حداقل ۲ حرف باشد'; end if;
  if exists(select 1 from family_members where user_id=me and role='parent' and status='active') then raise exception 'شما از قبل یک خانواده دارید'; end if;
  insert into families(name, owner_id) values (trim(p_name), me) returning id into fid;
  insert into family_members(family_id,user_id,role) values (fid, me, 'parent');
  perform log_event(fid, me, 'family_created', 'family', fid);
  return fid;
end $$;

create function public.generate_connection_code(p_family uuid) returns text language plpgsql security definer set search_path = public, extensions as $$
declare me uuid := auth.uid(); alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; code text := ''; i int;
begin
  if not is_parent(p_family) then raise exception 'دسترسی ندارید'; end if;
  update connection_codes set status='revoked' where family_id=p_family and status='active';
  for i in 1..8 loop code := code || substr(alphabet, 1 + (get_byte(extensions.gen_random_bytes(1),0) % 32), 1); end loop;
  insert into connection_codes(family_id, code_hash, expires_at)
  values (p_family, encode(extensions.digest(code,'sha256'),'hex'), now() + interval '24 hours');
  perform log_event(p_family, me, 'code_generated', 'family', p_family);
  return code;
end $$;

create function public.request_connection(p_code text) returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare me uuid := auth.uid(); c connection_codes; cnt int; rid uuid; nm text;
begin
  if me is null then raise exception 'ابتدا وارد حساب شوید'; end if;
  select display_name into nm from profiles where id=me;
  if (select role from profiles where id=me) <> 'child' then
    return jsonb_build_object('ok',false,'message','فقط حساب فرزند می‌تواند به خانواده متصل شود'); end if;
  select count(*) into cnt from code_attempts where user_id=me and at > now() - interval '10 minutes';
  if cnt >= 10 then return jsonb_build_object('ok',false,'message','تلاش‌های شما زیاد بود؛ چند دقیقه بعد دوباره امتحان کنید'); end if;
  insert into code_attempts(user_id) values (me);
  select * into c from connection_codes
   where code_hash = encode(extensions.digest(upper(trim(p_code)),'sha256'),'hex')
     and status='active' and expires_at > now() and uses_count < max_uses for update;
  if not found then return jsonb_build_object('ok',false,'message','کد نامعتبر یا منقضی است'); end if;
  if exists(select 1 from family_members where user_id=me and role='child' and status='active') then
    return jsonb_build_object('ok',false,'message','شما از قبل به یک خانواده متصل هستید'); end if;
  if (select count(*) from family_members where family_id=c.family_id and role='child' and status='active') >= 5 then
    return jsonb_build_object('ok',false,'message','ظرفیت این خانواده (۵ فرزند) تکمیل است'); end if;
  if exists(select 1 from connection_requests where family_id=c.family_id and child_id=me and status='pending') then
    return jsonb_build_object('ok',false,'message','درخواست قبلی شما هنوز در انتظار تأیید والد است'); end if;
  insert into connection_requests(family_id, child_id) values (c.family_id, me) returning id into rid;
  update connection_codes set uses_count = uses_count + 1 where id = c.id;
  perform push_to_parents(c.family_id, 'connection_request', 'درخواست اتصال جدید', nm || ' می‌خواهد به خانواده بپیوندد', rid);
  perform log_event(c.family_id, me, 'connection_requested', 'connection_request', rid);
  return jsonb_build_object('ok',true,'message','درخواست ارسال شد؛ منتظر تأیید والد باشید');
end $$;

create function public.review_connection(p_request uuid, p_approve boolean) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r connection_requests;
begin
  select * into r from connection_requests where id=p_request for update;
  if not found then raise exception 'درخواست پیدا نشد'; end if;
  if not is_parent(r.family_id) then raise exception 'دسترسی ندارید'; end if;
  if r.status <> 'pending' then raise exception 'این درخواست قبلاً بررسی شده است'; end if;
  if p_approve then
    if (select count(*) from family_members where family_id=r.family_id and role='child' and status='active') >= 5 then
      raise exception 'ظرفیت خانواده (۵ فرزند) تکمیل است'; end if;
    if exists(select 1 from family_members where user_id=r.child_id and role='child' and status='active') then
      raise exception 'این فرزند به خانواده دیگری متصل شده است'; end if;
    insert into family_members(family_id,user_id,role,status) values (r.family_id, r.child_id, 'child', 'active')
      on conflict (family_id,user_id) do update set status='active', role='child', joined_at=now();
    insert into star_balances(family_id,child_id,total_stars) values (r.family_id, r.child_id, 0) on conflict do nothing;
    update connection_requests set status='approved', reviewed_at=now(), reviewed_by=me where id=r.id;
    perform push_notification(r.child_id,'connection_approved','اتصال تأیید شد','اکنون عضو خانواده هستید',r.family_id);
    perform log_event(r.family_id, me, 'connection_approved', 'connection_request', r.id);
  else
    update connection_requests set status='rejected', reviewed_at=now(), reviewed_by=me where id=r.id;
    perform push_notification(r.child_id,'connection_rejected','درخواست اتصال رد شد','والد درخواست شما را نپذیرفت',r.family_id);
    perform log_event(r.family_id, me, 'connection_rejected', 'connection_request', r.id);
  end if;
  return true;
end $$;

create function public.remove_member(p_family uuid, p_child uuid) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
  if not is_parent(p_family) then raise exception 'دسترسی ندارید'; end if;
  update family_members set status='removed' where family_id=p_family and user_id=p_child and role='child' and status='active';
  if not found then raise exception 'عضو پیدا نشد'; end if;
  update mission_recipients set status='cancelled' where family_id=p_family and child_id=p_child and status in ('pending','accepted','needs_revision');
  perform push_notification(p_child,'member_removed','اتصال قطع شد','والد شما را از خانواده جدا کرد',p_family);
  perform log_event(p_family, me, 'member_removed', 'user', p_child);
  return true;
end $$;

-- ========== مأموریت‌ها ==========
create function public.create_mission(p_family uuid, p_title text, p_desc text, p_reward int, p_start timestamptz,
  p_deadline timestamptz, p_children uuid[], p_mode text, p_priority text) returns uuid
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); mid uuid; ch uuid;
begin
  if not is_parent(p_family) then raise exception 'دسترسی ندارید'; end if;
  if char_length(trim(coalesce(p_title,''))) = 0 then raise exception 'عنوان نمی‌تواند خالی باشد'; end if;
  if char_length(trim(coalesce(p_desc,''))) = 0 then raise exception 'توضیحات نمی‌تواند خالی باشد'; end if;
  if char_length(p_title) > 80 or char_length(p_desc) > 500 then raise exception 'متن عنوان یا توضیحات بیش از حد طولانی است'; end if;
  if p_reward is null or p_reward <= 0 then raise exception 'تعداد ستاره باید مثبت باشد'; end if;
  if p_deadline <= now() then raise exception 'مهلت باید در آینده باشد'; end if;
  if p_start is not null and p_deadline <= p_start then raise exception 'مهلت پایان باید بعد از شروع باشد'; end if;
  if p_mode not in ('competitive','individual') then raise exception 'حالت مأموریت نامعتبر است'; end if;
  if coalesce(array_length(p_children,1),0) = 0 then raise exception 'حداقل یک فرزند را انتخاب کنید'; end if;
  foreach ch in array p_children loop
    if not exists(select 1 from family_members where family_id=p_family and user_id=ch and role='child' and status='active') then
      raise exception 'فرزند انتخاب‌شده عضو این خانواده نیست'; end if;
  end loop;
  insert into missions(family_id,created_by,title,description,reward_stars,start_at,deadline_at,assignment_mode,priority)
  values (p_family, me, trim(p_title), trim(p_desc), p_reward, p_start, p_deadline, p_mode,
          case when p_priority='important' then 'important' else 'normal' end) returning id into mid;
  foreach ch in array (select array_agg(distinct x) from unnest(p_children) x) loop
    insert into mission_recipients(mission_id,family_id,child_id) values (mid, p_family, ch);
    perform push_notification(ch,'mission_new','مأموریت جدید',trim(p_title),mid);
  end loop;
  perform log_event(p_family, me, 'mission_created', 'mission', mid, jsonb_build_object('title',trim(p_title),'reward',p_reward));
  return mid;
end $$;

create function public.accept_mission(p_recipient uuid) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); rec mission_recipients; m missions; nm text;
begin
  select * into rec from mission_recipients where id=p_recipient;
  if not found or rec.child_id <> me then raise exception 'مأموریت پیدا نشد'; end if;
  select * into m from missions where id=rec.mission_id for update;       -- قفل مأموریت: پذیرش اتمیک
  select * into rec from mission_recipients where id=p_recipient for update;
  if m.status <> 'active' then raise exception 'این مأموریت لغو شده است'; end if;
  if rec.status = 'taken_by_other' then raise exception 'این مأموریت توسط فرزند دیگری پذیرفته شد'; end if;
  if rec.status <> 'pending' then raise exception 'این مأموریت قابل پذیرش نیست'; end if;
  if m.deadline_at <= now() then raise exception 'مهلت این مأموریت تمام شده است'; end if;
  if m.assignment_mode = 'competitive' and exists(
      select 1 from mission_recipients where mission_id=m.id and id<>rec.id and status in ('accepted','submitted','needs_revision','approved')) then
    raise exception 'این مأموریت توسط فرزند دیگری پذیرفته شد'; end if;
  update mission_recipients set status='accepted', accepted_at=now() where id=rec.id;
  if m.assignment_mode = 'competitive' then
    update mission_recipients set status='taken_by_other' where mission_id=m.id and id<>rec.id and status='pending';
    insert into notifications(user_id,type,title,message,related_entity_id)
    select child_id,'mission_taken','مأموریت پذیرفته شد','«'||m.title||'» توسط فرزند دیگری پذیرفته شد',m.id
    from mission_recipients where mission_id=m.id and status='taken_by_other';
  end if;
  select display_name into nm from profiles where id=me;
  perform push_to_parents(m.family_id,'mission_accepted','پذیرش مأموریت',nm||' «'||m.title||'» را پذیرفت',m.id);
  perform log_event(m.family_id, me, 'mission_accepted', 'mission_recipient', rec.id, jsonb_build_object('title',m.title));
  return true;
end $$;

create function public.decline_mission(p_recipient uuid) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); rec mission_recipients; m missions; nm text;
begin
  select * into rec from mission_recipients where id=p_recipient for update;
  if not found or rec.child_id <> me then raise exception 'مأموریت پیدا نشد'; end if;
  if rec.status <> 'pending' then raise exception 'این مأموریت قابل رد نیست'; end if;
  select * into m from missions where id=rec.mission_id;
  update mission_recipients set status='declined' where id=rec.id;
  select display_name into nm from profiles where id=me;
  perform push_to_parents(m.family_id,'mission_declined','رد مأموریت',nm||' «'||m.title||'» را قبول نکرد',m.id);
  perform log_event(m.family_id, me, 'mission_declined', 'mission_recipient', rec.id, jsonb_build_object('title',m.title));
  return true;
end $$;

create function public.submit_mission(p_recipient uuid, p_note text default null) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); rec mission_recipients; m missions; nm text;
begin
  select * into rec from mission_recipients where id=p_recipient for update;
  if not found or rec.child_id <> me then raise exception 'مأموریت پیدا نشد'; end if;
  select * into m from missions where id=rec.mission_id;
  if m.status <> 'active' then raise exception 'این مأموریت لغو شده است'; end if;
  if rec.status not in ('accepted','needs_revision') then raise exception 'در این وضعیت امکان اعلام پایان کار نیست'; end if;
  if m.deadline_at <= now() then raise exception 'مهلت تمام شده است؛ از والد بخواهید مهلت را تمدید کند'; end if;
  update mission_recipients set status='submitted', completed_at=now(), child_note=nullif(trim(p_note),'') where id=rec.id;
  select display_name into nm from profiles where id=me;
  perform push_to_parents(m.family_id,'mission_submitted','نیاز به بررسی',nm||' کار «'||m.title||'» را تمام کرد',m.id);
  perform log_event(m.family_id, me, 'mission_submitted', 'mission_recipient', rec.id, jsonb_build_object('title',m.title));
  return true;
end $$;

create function public.review_mission(p_recipient uuid, p_decision text, p_note text default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); rec mission_recipients; m missions; bal int;
begin
  select * into rec from mission_recipients where id=p_recipient for update;
  if not found then raise exception 'مورد پیدا نشد'; end if;
  if not is_parent(rec.family_id) then raise exception 'دسترسی ندارید'; end if;
  if rec.status <> 'submitted' then raise exception 'این مأموریت در انتظار بررسی نیست'; end if;
  select * into m from missions where id=rec.mission_id;
  if p_decision = 'approve' then
    insert into star_balances(family_id,child_id,total_stars) values (rec.family_id, rec.child_id, 0) on conflict do nothing;
    select total_stars into bal from star_balances where family_id=rec.family_id and child_id=rec.child_id for update;
    insert into star_ledger(family_id,child_id,actor_id,event_type,amount,balance_before,balance_after,reason,mission_id,idempotency_key)
    values (rec.family_id, rec.child_id, me, 'mission_reward', m.reward_stars, bal, bal + m.reward_stars, m.title, m.id, 'reward:' || rec.id);
    update star_balances set total_stars = bal + m.reward_stars where family_id=rec.family_id and child_id=rec.child_id;
    update mission_recipients set status='approved', reviewed_at=now(), reviewed_by=me, review_note=nullif(trim(p_note),'') where id=rec.id;
    perform push_notification(rec.child_id,'mission_approved','مأموریت تأیید شد','تبریک! '||m.reward_stars||' ستاره گرفتید',m.id);
    perform log_event(rec.family_id, me, 'mission_approved', 'mission_recipient', rec.id, jsonb_build_object('title',m.title,'stars',m.reward_stars));
  elsif p_decision in ('reject','revise') then
    if char_length(trim(coalesce(p_note,''))) = 0 then raise exception 'نوشتن دلیل الزامی است'; end if;
    update mission_recipients set status = case when p_decision='reject' then 'rejected' else 'needs_revision' end,
      reviewed_at=now(), reviewed_by=me, review_note=trim(p_note) where id=rec.id;
    perform push_notification(rec.child_id, case when p_decision='reject' then 'mission_rejected' else 'mission_revision' end,
      case when p_decision='reject' then 'نتیجه رد شد' else 'نیاز به اصلاح' end, m.title||': '||trim(p_note), m.id);
    perform log_event(rec.family_id, me, case when p_decision='reject' then 'mission_rejected' else 'mission_revision' end,
      'mission_recipient', rec.id, jsonb_build_object('title',m.title,'note',trim(p_note)));
  else raise exception 'تصمیم نامعتبر است';
  end if;
  return true;
end $$;

create function public.deduct_stars(p_family uuid, p_child uuid, p_amount int, p_reason text, p_note text, p_key text) returns boolean
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); bal int; k text := p_family || ':' || p_key;
begin
  if not is_parent(p_family) then raise exception 'دسترسی ندارید'; end if;
  if not exists(select 1 from family_members where family_id=p_family and user_id=p_child and role='child' and status='active') then
    raise exception 'فرزند عضو فعال این خانواده نیست'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'تعداد ستاره باید مثبت باشد'; end if;
  if char_length(trim(coalesce(p_reason,''))) = 0 then raise exception 'دلیل کسر الزامی است'; end if;
  if exists(select 1 from star_ledger where idempotency_key = k) then return true; end if;   -- درخواست تکراری
  insert into star_balances(family_id,child_id,total_stars) values (p_family, p_child, 0) on conflict do nothing;
  select total_stars into bal from star_balances where family_id=p_family and child_id=p_child for update;
  if bal < p_amount then raise exception 'ستاره کافی نیست؛ موجودی فعلی % است', bal; end if;
  insert into star_ledger(family_id,child_id,actor_id,event_type,amount,balance_before,balance_after,reason,note,idempotency_key)
  values (p_family, p_child, me, 'deduction', -p_amount, bal, bal - p_amount, trim(p_reason), nullif(trim(p_note),''), k);
  update star_balances set total_stars = bal - p_amount where family_id=p_family and child_id=p_child;
  perform push_notification(p_child,'stars_deducted','کسر ستاره',p_amount||' ستاره کسر شد: '||trim(p_reason),p_family);
  perform log_event(p_family, me, 'deduction', 'user', p_child, jsonb_build_object('amount',p_amount,'reason',trim(p_reason)));
  return true;
end $$;

create function public.extend_deadline(p_mission uuid, p_deadline timestamptz) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); m missions;
begin
  select * into m from missions where id=p_mission for update;
  if not found or not is_parent(m.family_id) then raise exception 'دسترسی ندارید'; end if;
  if m.status <> 'active' then raise exception 'مأموریت لغو شده است'; end if;
  if p_deadline <= now() then raise exception 'مهلت جدید باید در آینده باشد'; end if;
  update missions set deadline_at = p_deadline where id = m.id;
  update mission_recipients set status = case when accepted_at is null then 'pending' else 'accepted' end
    where mission_id = m.id and status = 'expired';
  insert into notifications(user_id,type,title,message,related_entity_id)
    select child_id,'deadline_extended','تمدید مهلت','مهلت «'||m.title||'» تمدید شد',m.id
    from mission_recipients where mission_id=m.id and status in ('pending','accepted','needs_revision');
  perform log_event(m.family_id, me, 'deadline_extended', 'mission', m.id, jsonb_build_object('title',m.title));
  return true;
end $$;

create function public.cancel_mission(p_mission uuid) returns boolean language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); m missions;
begin
  select * into m from missions where id=p_mission for update;
  if not found or not is_parent(m.family_id) then raise exception 'دسترسی ندارید'; end if;
  if m.status <> 'active' then raise exception 'مأموریت قبلاً لغو شده است'; end if;
  update missions set status='cancelled' where id=m.id;
  insert into notifications(user_id,type,title,message,related_entity_id)
    select child_id,'mission_cancelled','لغو مأموریت','«'||m.title||'» لغو شد',m.id
    from mission_recipients where mission_id=m.id and status in ('pending','accepted','needs_revision');
  update mission_recipients set status='cancelled' where mission_id=m.id and status in ('pending','accepted','needs_revision');
  perform log_event(m.family_id, me, 'mission_cancelled', 'mission', m.id, jsonb_build_object('title',m.title));
  return true;
end $$;

create function public.expire_missions(p_family uuid) returns boolean language plpgsql security definer set search_path = public as $$
begin
  if not is_member(p_family) then raise exception 'دسترسی ندارید'; end if;
  with e as (
    update mission_recipients r set status='expired' from missions m
     where r.mission_id=m.id and m.family_id=p_family and m.status='active'
       and r.status in ('pending','accepted','needs_revision') and m.deadline_at < now()
    returning r.child_id, m.title, m.id as mid)
  insert into notifications(user_id,type,title,message,related_entity_id)
  select child_id,'mission_expired','مهلت تمام شد','مهلت «'||title||'» تمام شد',mid from e;
  return true;
end $$;

create function public.mark_notification_read(p_id uuid) returns boolean language sql security definer set search_path = public as $$
  update notifications set read_at = now() where id = p_id and user_id = auth.uid() and read_at is null; select true $$;
create function public.mark_all_read() returns boolean language sql security definer set search_path = public as $$
  update notifications set read_at = now() where user_id = auth.uid() and read_at is null; select true $$;

-- ========== امنیت سطح سطر (RLS) ==========
alter table public.profiles enable row level security;
alter table public.families enable row level security;
alter table public.family_members enable row level security;
alter table public.connection_codes enable row level security;
alter table public.code_attempts enable row level security;
alter table public.connection_requests enable row level security;
alter table public.missions enable row level security;
alter table public.mission_recipients enable row level security;
alter table public.star_balances enable row level security;
alter table public.star_ledger enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_events enable row level security;

create policy p_profiles on public.profiles for select to authenticated using (
  id = auth.uid()
  or exists(select 1 from family_members a join family_members b on a.family_id=b.family_id
            where a.user_id=auth.uid() and a.status='active' and b.user_id=profiles.id)
  or exists(select 1 from connection_requests cr where cr.child_id=profiles.id and public.is_parent(cr.family_id)));
create policy p_families on public.families for select to authenticated using (public.is_member(id));
create policy p_members on public.family_members for select to authenticated using (user_id = auth.uid() or public.is_member(family_id));
create policy p_requests on public.connection_requests for select to authenticated using (child_id = auth.uid() or public.is_parent(family_id));
create policy p_missions on public.missions for select to authenticated using (
  public.is_parent(family_id) or exists(select 1 from mission_recipients r where r.mission_id=missions.id and r.child_id=auth.uid()));
create policy p_recipients on public.mission_recipients for select to authenticated using (child_id = auth.uid() or public.is_parent(family_id));
create policy p_balances on public.star_balances for select to authenticated using (child_id = auth.uid() or public.is_parent(family_id));
create policy p_ledger on public.star_ledger for select to authenticated using (child_id = auth.uid() or public.is_parent(family_id));
create policy p_notifs on public.notifications for select to authenticated using (user_id = auth.uid());
create policy p_audit on public.audit_events for select to authenticated using (public.is_parent(family_id));
-- connection_codes و code_attempts: هیچ سیاستی ندارند، یعنی از کلاینت قابل خواندن نیستند.

-- هیچ نوشتن مستقیمی از کلاینت ممکن نیست؛ فقط از طریق توابع بالا
revoke all on all tables in schema public from anon, authenticated;
grant select on public.profiles, public.families, public.family_members, public.connection_requests, public.missions,
  public.mission_recipients, public.star_balances, public.star_ledger, public.notifications, public.audit_events to authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_member(uuid), public.is_parent(uuid), public.create_family(text),
  public.generate_connection_code(uuid), public.request_connection(text), public.review_connection(uuid,boolean),
  public.remove_member(uuid,uuid), public.create_mission(uuid,text,text,int,timestamptz,timestamptz,uuid[],text,text),
  public.accept_mission(uuid), public.decline_mission(uuid), public.submit_mission(uuid,text),
  public.review_mission(uuid,text,text), public.deduct_stars(uuid,uuid,int,text,text,text),
  public.extend_deadline(uuid,timestamptz), public.cancel_mission(uuid), public.expire_missions(uuid),
  public.mark_notification_read(uuid), public.mark_all_read() to authenticated;

-- همگام‌سازی لحظه‌ای
alter publication supabase_realtime add table public.missions, public.mission_recipients, public.star_balances,
  public.star_ledger, public.notifications, public.connection_requests, public.family_members;
