import 'package:flutter/material.dart';
import 'core.dart';
import 'shared.dart';

class ChildRoot extends StatelessWidget {
  const ChildRoot({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Live<Json>(
          tables: const ['family_members', 'connection_requests'],
          loader: () async => {
            'm': await sb.from('family_members').select('family_id, families(name)').eq('user_id', uid).eq('role', 'child').eq('status', 'active').maybeSingle(),
            'reqs': rows(await sb.from('connection_requests').select('id,status,created_at').eq('child_id', uid).order('created_at', ascending: false).limit(5)),
          },
          builder: (c, d, refresh) => d['m'] != null
              ? ChildHome(fid: d['m']['family_id'], fname: d['m']['families']?['name'] ?? 'خانواده')
              : JoinPage(reqs: d['reqs'] as List<Json>, onDone: refresh),
        ),
      );
}

class JoinPage extends StatefulWidget {
  final List<Json> reqs;
  final Future<void> Function() onDone;
  const JoinPage({super.key, required this.reqs, required this.onDone});
  @override
  State<JoinPage> createState() => _JoinPageState();
}

class _JoinPageState extends State<JoinPage> {
  final code = TextEditingController();
  bool busy = false;
  @override
  Widget build(BuildContext context) {
    final pending = widget.reqs.any((r) => r['status'] == 'pending');
    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(24), children: [
        const SizedBox(height: 30),
        const Icon(Icons.link, size: 80, color: navy),
        const Center(child: Text('اتصال به خانواده', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        if (pending)
          const Card(color: Color(0xFFFFF6DA), child: Padding(padding: EdgeInsets.all(16), child: Text('درخواست شما ارسال شده و منتظر تأیید والد است. تا آن زمان به اطلاعات خانواده دسترسی ندارید.')))
        else ...[
          const Text('کدی را که والد به شما داده وارد کنید:'),
          const SizedBox(height: 8),
          TextField(controller: code, textCapitalization: TextCapitalization.characters, textDirection: TextDirection.ltr, textAlign: TextAlign.center, maxLength: 8,
              style: const TextStyle(fontSize: 26, letterSpacing: 4), decoration: const InputDecoration(border: OutlineInputBorder())),
          FilledButton(
            onPressed: busy ? null : () async {
              setState(() => busy = true);
              final r = await run(context, () => sb.rpc('request_connection', params: {'p_code': code.text}));
              if (!mounted) return;
              setState(() => busy = false);
              if (r is Map) {
                toast(context, r['message'] ?? '', err: r['ok'] != true);
                if (r['ok'] == true) await widget.onDone();
              }
            },
            child: const Text('ارسال درخواست اتصال')),
        ],
        if (widget.reqs.isNotEmpty && widget.reqs.first['status'] == 'rejected')
          const Padding(padding: EdgeInsets.only(top: 12), child: Text('آخرین درخواست شما رد شد.', style: TextStyle(color: red))),
        TextButton(onPressed: () => sb.auth.signOut(), child: const Text('خروج از حساب')),
      ]),
    );
  }
}

class ChildHome extends StatefulWidget {
  final String fid, fname;
  const ChildHome({super.key, required this.fid, required this.fname});
  @override
  State<ChildHome> createState() => _ChildHomeState();
}

class _ChildHomeState extends State<ChildHome> {
  int i = 0;
  Future<Json> load() async {
    try { await sb.rpc('expire_missions', params: {'p_family': widget.fid}); } catch (_) {}
    final b = await sb.from('star_balances').select().eq('family_id', widget.fid).eq('child_id', uid).maybeSingle();
    return {'stars': b?['total_stars'] ?? 0, 'recs': await loadRecs(child: uid)};
  }

  Widget home() => Live<Json>(
        tables: const ['mission_recipients', 'star_balances'],
        loader: load,
        builder: (c, d, refresh) {
          final recs = d['recs'] as List<Json>;
          final name = sb.auth.currentUser?.userMetadata?['display_name'] ?? '';
          List<Widget> section(String t, List<String> st) {
            final l = recs.where((r) => st.contains(r['status'])).toList();
            if (l.isEmpty) return [];
            return [Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))), for (final r in l) MissionTile(rec: r, parent: false)];
          }
          return RefreshIndicator(
            onRefresh: refresh,
            child: ListView(padding: const EdgeInsets.all(12), children: [
              StarCard(name: name, stars: d['stars'] as int),
              ...section('مأموریت‌های جدید', ['pending']),
              ...section('در حال انجام / نیازمند اصلاح', ['accepted', 'needs_revision']),
              ...section('در انتظار بررسی والد', ['submitted']),
              ...section('نتیجه‌ها', ['approved', 'rejected', 'declined', 'taken_by_other', 'cancelled', 'expired']),
              if (recs.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('هنوز مأموریتی ندارید'))),
            ]),
          );
        },
      );

  @override
  Widget build(BuildContext context) {
    final pages = [
      home(),
      HistoryPage(fid: widget.fid, parent: false),
      const NotificationsPage(),
      ListView(children: [
        ListTile(leading: const Icon(Icons.logout, color: red), title: const Text('خروج از حساب'), onTap: () async {
          if (await confirmDlg(context, 'خروج', 'از حساب خارج می‌شوید؟')) await sb.auth.signOut();
        }),
      ]),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(widget.fname), backgroundColor: navy, foregroundColor: Colors.white),
      body: pages[i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.history), label: 'ستاره‌ها'),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'اعلان‌ها'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
        ],
      ),
    );
  }
}
